enum class CharacterClass {
    RED_GUARD,
    VOIDWARDEN,
    HATCHET,
    DEMOLITIONIST
}